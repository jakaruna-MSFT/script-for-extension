﻿[DSCLocalConfigurationManager()]

configuration LocalSettings
{
    node localhost

    {
        Settings
        {
            RefreshFrequencyMins = $RefreshFrequencyMins
        }

    }
}

configuration Tester

{

    param 

    ( 

        [Parameter(Mandatory = $true)]

        [string] $AdminUsername,
        
        [Parameter(Mandatory = $false)]

        [integer] $RefreshFrequencyMins

    );


    node localhost

    {

        File "tools"
        {

            Ensure = "Present"

            DestinationPath = "C:\tools.txt"

            Contents = "$AdminUsername"
        }

    }

}