﻿
configuration Tester

{

    param 

    ( 

        [Parameter(Mandatory = $true)]

        [string] $AdminUsername

    );


    node localhost

    {

        File "tools"
        {

            Ensure = "Present"

            Type = "Directory"

            DestinationPath = "C:\tools.txt"

            Contents = "$AdminUsername"
        }

    }

}