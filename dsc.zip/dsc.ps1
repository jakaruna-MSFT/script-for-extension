﻿[DSCLocalConfigurationManager()]

configuration LocalSettings

{
    param 

    ( 
       
        [Parameter(Mandatory = $false)]

        [int] $RefreshFrequencyMins

    );
    node localhost

    {
        Settings
        {
            RefreshFrequencyMins = $RefreshFrequencyMins
        }

    }
}

configuration Tester

{

    param 

    ( 

        [Parameter(Mandatory = $true)]

        [string] $AdminUsername

    );


    node localhost

    {

        File "tools"
        {

            Ensure = "Present"

            DestinationPath = "C:\tools.txt"

            Contents = "$AdminUsername"
        }

    }

}