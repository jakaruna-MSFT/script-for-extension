﻿Configuration TestUser
{
    param (
    [PSCredential] $MyCredential
    )
    Node localhost {
        User testing {
        UserName=$user
        Description="some description"
        Disabled=$False
        Ensure="Present"
        Password=$MyCredential
        PasswordNeverExpires = $true
        }
    }
}