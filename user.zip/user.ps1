﻿Configuration TestUser1
{
    param (
    [PSCredential] $MyCredential
    )
    Node localhost {
        User testing {
        UserName=$MyCredential.UserName
        Description="some description"
        Disabled=$False
        Ensure="Present"
        Password=$MyCredential
        PasswordNeverExpires = $true
        }
    }
}